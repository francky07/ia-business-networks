#!/usr/bin/env python3
import os, time, json, random, secrets, base64, requests, hashlib
from datetime import datetime
from web3 import Web3
from ecdsa import SigningKey, SECP256k1

PRIVATE_KEY = "5a72dc7a6a3a2d56b6e1fbdb5f4e11393190da2303df376a78277a3de2197b80"
OPENAI_API_KEY = "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"
GITHUB_USERNAME = "ianetpy"
GITHUB_TOKEN = "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"   # remplacez par votre token valide
TELEGRAM_BOT_TOKEN = "6828632307:AAFf6yu_UyrVe4JyRrjaKNEbbKSFuT8cpZM"
TELEGRAM_CHAT_ID = ""

AFF_BINANCE = "https://www.binance.com/referral/earn-together/refer2earn-usdc/claim?hl=fr&ref=GRO_28502_2P5Q3&utm_source=referral_entrance"
AFF_ALIEXPRESS = "https://www.aliexpress.com/ssr/300003044/global-june-mega-sale-2026-27gyo9?disableNav=YES&pha_manifest=ssr&_immersiveMode=true&businessCode=guide&wh_pid=300003044/global-june-mega-sale-2026-27gyo9&wh_ttid=adc&adc_strategy=prerender&_wv_preload=true&adc_direct_ssr=true"

w3 = Web3(Web3.HTTPProvider("https://bsc-dataseed1.binance.org"))
account = w3.eth.account.from_key(PRIVATE_KEY)
WALLET = account.address
print(f"✅ Wallet: {WALLET}")

MEM_FILE = "ia_mem.json"
def load_memory():
    if os.path.exists(MEM_FILE):
        with open(MEM_FILE) as f: return json.load(f)
    return {"stats":{"cycle":0,"actions":0},"errors":[]}
def save_memory(d): open(MEM_FILE,"w").write(json.dumps(d))

def send_telegram(message):
    global TELEGRAM_CHAT_ID
    if TELEGRAM_BOT_TOKEN:
        if not TELEGRAM_CHAT_ID:
            try:
                url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates"
                r = requests.get(url, timeout=15)
                if r.status_code == 200 and r.json()["result"]:
                    TELEGRAM_CHAT_ID = str(r.json()["result"][0]["message"]["chat"]["id"])
            except: pass
        if TELEGRAM_CHAT_ID:
            for _ in range(3):
                try:
                    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
                    requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": message}, timeout=15)
                    break
                except: time.sleep(2)

class RLAgent:
    def __init__(self, name, alpha=0.1, gamma=0.9, epsilon=0.2):
        self.name=name; self.alpha=alpha; self.gamma=gamma; self.epsilon=epsilon
        self.q={}; self.last_state=None; self.last_action=None; self.last_reward=0
    def _state(self, balance, err_rate, cycle):
        b=int(balance*100) if balance<1 else min(5,int(balance))
        e=0 if err_rate<0.05 else (1 if err_rate<0.2 else 2)
        c=cycle%10
        return (b,e,c)
    def act(self, balance, err_rate, cycle):
        s=self._state(balance,err_rate,cycle)
        if random.random()<self.epsilon:
            a=random.randint(0,4)
        else:
            qv=[self.q.get((s,a),0.0) for a in range(5)]
            a=max(range(5), key=lambda x: qv[x])
        self.last_state=s; self.last_action=a
        return a
    def reward(self,r): self.last_reward=r
    def commit(self, balance, err_rate, cycle):
        if self.last_state is not None:
            ns=self._state(balance,err_rate,cycle)
            old=self.q.get((self.last_state,self.last_action),0.0)
            nxt_max=max([self.q.get((ns,a),0.0) for a in range(5)], default=0.0)
            new=old+self.alpha*(self.last_reward+self.gamma*nxt_max-old)
            self.q[(self.last_state,self.last_action)]=new
            self.last_state=None; self.last_action=None; self.last_reward=0
rl_agents = [RLAgent(f"RL_{i}", epsilon=0.15+0.02*i) for i in range(10)]

def inno_idea(): print(f"💡 Innovation: {random.sample(['NFT','Bot Discord','Jeu'],2)}")
def leader_goal(): print(f"🎯 Objectif: {random.choice(['Augmenter fichiers','Réduire erreurs'])}")
def opp_scan(): print(f"🔍 Opportunité: {random.choice(['Tendance IA','Prix BNB bas'])}")
def creativity(): print(f"🎨 Concept: {random.sample(['blog','bot','app'],2)}")
def strategy_pace(errors): print(f"⚙️ Stratégie: {'Expansion' if len(errors)<5 else 'Consolidation'}")

class OpAgents:
    def __init__(self,parent): self.parent=parent
    def run(self):
        agents=[("DG","Coordination"),("S1","Strat"),("S2","Strat"),("R1","Ress"),("R2","Ress")]+[(f"M{i}","Rech") for i in range(1,5)]+[(f"V{i}","Tech") for i in range(1,3)]+[(f"O{i}","Opp") for i in range(1,3)]+[(f"C{i}","Contenu") for i in range(1,6)]+[(f"D{i}","Dev") for i in range(1,5)]+[(f"B{i}","BDD") for i in range(1,3)]+[(f"MK{i}","Marketing") for i in range(1,5)]+[(f"SEO{i}","SEO") for i in range(1,4)]+[(f"SO{i}","Social") for i in range(1,3)]+[(f"DA{i}","Analyse") for i in range(1,3)]+[(f"RO{i}","Revenus") for i in range(1,3)]+[(f"Q{i}","Qualité") for i in range(1,3)]+[(f"SU{i}","Support") for i in range(1,3)]+[("Doc","Admin")]+[(f"CY{i}","Sécu") for i in range(1,3)]+[(f"AU{i}","Audit") for i in range(1,3)]
        for name,role in agents:
            self.parent.log_action(name,role,"OK")
        return True

class NetSolutions:
    def __init__(self):
        self.wallet = WALLET
        self.mem = load_memory()
        self.op = OpAgents(self)
        self.rl = rl_agents
        self.prev_balance = 0.0
        self.prev_errors = 0
    def log_action(self,n,r,s): print(f"  [{n}] {r}: {s}")
    def check_balance(self):
        try: return float(w3.from_wei(w3.eth.get_balance(self.wallet),'ether'))
        except: return 0.0
    def task_blog(self):
        article = "<p>Découvrez nos partenaires : Binance et AliExpress.</p>"
        if OPENAI_API_KEY and OPENAI_API_KEY.startswith("sk-"):
            try:
                h={"Authorization":f"Bearer {OPENAI_API_KEY}","Content-Type":"application/json"}
                d={"model":"gpt-3.5-turbo","messages":[{"role":"user","content":f"Rédige un court article SEO sur crypto et IA, avec appel aux dons sur {self.wallet} et nos liens parrainage Binance et AliExpress."}]}
                r=requests.post("https://api.openai.com/v1/chat/completions", headers=h, json=d, timeout=15)
                if r.status_code==200: article=r.json()["choices"][0]["message"]["content"]
            except: pass
