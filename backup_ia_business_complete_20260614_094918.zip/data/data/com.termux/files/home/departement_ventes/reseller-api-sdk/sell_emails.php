<?php
require 'vendor/autoload.php';

use ITAccfarm\ResellerSDK\ResellerSDK;

// 🔑 Remplace par ton email et mot de passe Accfarm (inscription gratuite)
$email = "seckndananeuh@gmail.com";
$password = "SaintLouis65#";

$api = new ResellerSDK();
$auth = $api->auth($email, $password);
if (!$auth || empty($auth['bearerToken'])) {
    die("❌ Échec de l'authentification. Vérifie tes identifiants.\n");
}

$bearerToken = $auth['bearerToken'];
$userSecret = $auth['userSecret'];

// 📧 Récupère les emails depuis keys.json (fichier généré par ton bot)
$keysFile = $_SERVER['HOME'] . '/agence_kays/keys.json';
$data = json_decode(file_get_contents($keysFile), true);
$emails = $data['emails'] ?? [];

if (count($emails) == 0) {
    echo "Aucun email à vendre.\n";
    exit(0);
}

// 💰 Vente des emails (0,01 $ par email, adaptable)
$api->setToken($bearerToken);
$api->setSecret($userSecret);
$result = $api->buy([
    'product_id' => 1,      // ID du produit pour les emails génériques
    'quantity'   => count($emails),
    'price'      => count($emails) * 0.01,
]);

if ($result && !empty($result['success'])) {
    echo "✅ Vente réussie : " . count($emails) . " emails vendus.\n";
    // Vider la liste des emails après vente
    $data['emails'] = [];
    file_put_contents($keysFile, json_encode($data, JSON_PRETTY_PRINT));
} else {
    echo "❌ Échec de la vente.\n";
}
?>
