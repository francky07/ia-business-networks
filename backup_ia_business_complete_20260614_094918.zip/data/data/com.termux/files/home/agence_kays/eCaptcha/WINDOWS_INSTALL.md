# Windows Installation Guide

This guide will help you install the reCAPTCHA v2 Enterprise Solver on Windows, specifically addressing the common dependency issues.

## Quick Fix for Current Error

If you're getting the `distutils` error, follow these steps:

### Method 1: Using the Installation Script (Recommended)

1. **Run the PowerShell script:**
   ```powershell
   .\install_windows.ps1
   ```

   Or if PowerShell execution is disabled:
   ```cmd
   install_windows.bat
   ```

### Method 2: Manual Installation

1. **Update pip and install build tools:**
   ```cmd
   python -m pip install --upgrade pip
   pip install setuptools>=65.0.0 wheel>=0.38.0
   ```

2. **Install PyAudio using pipwin:**
   ```cmd
   pip install pipwin
   pipwin install pyaudio
   ```

3. **Install other dependencies:**
   ```cmd
   pip install -r requirements_windows.txt
   ```

4. **Verify installation:**
   ```cmd
   python -c "import fastapi, selenium, undetected_chromedriver, speech_recognition, pydub; print('Success!')"
   ```

## Alternative: Using Pre-built Wheels

If the above doesn't work, try installing pre-built wheels:

```cmd
pip install --only-binary=all -r requirements_windows.txt
```

## Common Windows Issues and Solutions

### 1. PyAudio Installation Fails

**Solution 1: Use pipwin**
```cmd
pip install pipwin
pipwin install pyaudio
```

**Solution 2: Download pre-built wheel**
```cmd
# For Python 3.12 on Windows
pip install https://download.lfd.uci.edu/pythonlibs/archived/PyAudio-0.2.11-cp312-cp312-win_amd64.whl
```

**Solution 3: Use conda**
```cmd
conda install pyaudio
```

### 2. Visual C++ Build Tools Required

If you get build errors, install Visual Studio Build Tools:

1. Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/
2. Install "C++ build tools" workload
3. Retry installation

### 3. Chrome Not Found

Make sure Google Chrome is installed:
- Download from: https://www.google.com/chrome/
- Install normally
- Verify it's in: `C:\Program Files\Google\Chrome\Application\chrome.exe`

### 4. Permission Errors

Run Command Prompt or PowerShell as Administrator:
1. Right-click on Command Prompt/PowerShell
2. Select "Run as administrator"
3. Navigate to your project directory
4. Run installation commands

### 5. Python Version Issues

The project works best with Python 3.8-3.11. If using Python 3.12:

```cmd
# Downgrade numpy to avoid issues
pip install numpy==1.24.3
```

## Step-by-Step Installation

### Prerequisites

1. **Python 3.8-3.11** (recommended)
   - Download from: https://www.python.org/downloads/
   - Check "Add Python to PATH" during installation

2. **Google Chrome**
   - Download from: https://www.google.com/chrome/

3. **Visual Studio Build Tools** (if needed)
   - Download from: https://visualstudio.microsoft.com/visual-cpp-build-tools/

### Installation Steps

1. **Open Command Prompt as Administrator**

2. **Navigate to project directory:**
   ```cmd
   cd "E:\NobanDev Repos\recaptcha_v2_solver"
   ```

3. **Create and activate virtual environment:**
   ```cmd
   python -m venv venv
   venv\Scripts\activate
   ```

4. **Update pip:**
   ```cmd
   python -m pip install --upgrade pip
   ```

5. **Install build tools:**
   ```cmd
   pip install setuptools>=65.0.0 wheel>=0.38.0
   ```

6. **Install PyAudio:**
   ```cmd
   pip install pipwin
   pipwin install pyaudio
   ```

7. **Install other dependencies:**
   ```cmd
   pip install -r requirements_windows.txt
   ```

8. **Verify installation:**
   ```cmd
   python -c "import fastapi, selenium, undetected_chromedriver, speech_recognition, pydub; print('All dependencies installed successfully!')"
   ```

9. **Start the server:**
   ```cmd
   python start.py
   ```

## Testing the Installation

After installation, test the setup:

```cmd
python test_solver.py
```

## Troubleshooting

### If you still get errors:

1. **Check Python version:**
   ```cmd
   python --version
   ```

2. **Check pip version:**
   ```cmd
   pip --version
   ```

3. **List installed packages:**
   ```cmd
   pip list
   ```

4. **Try installing packages one by one:**
   ```cmd
   pip install fastapi==0.104.1
   pip install uvicorn==0.24.0
   pip install requests==2.31.0
   # ... continue with other packages
   ```

### Alternative: Use Conda

If pip continues to fail, try using conda:

```cmd
conda create -n captcha_solver python=3.9
conda activate captcha_solver
conda install -c conda-forge pyaudio
pip install -r requirements_windows.txt
```

## Getting Help

If you continue to have issues:

1. Check the error messages carefully
2. Try the alternative installation methods above
3. Make sure you're using a compatible Python version
4. Ensure you have administrator privileges
5. Check that Chrome is properly installed

## Next Steps

After successful installation:

1. **Start the server:**
   ```cmd
   python start.py
   ```

2. **Test the API:**
   ```cmd
   python test_solver.py
   ```

3. **Access the API documentation:**
   - Open: http://localhost:8000/docs

4. **Try the examples:**
   ```cmd
   python examples/spotify_login_example.py
   ``` 