#!/usr/bin/env python3
"""
Alternative start script for reCAPTCHA v2 Enterprise Solver
"""

import os
import sys
import subprocess
import time

def check_dependencies():
    """Check if required dependencies are installed"""
    print("🔍 Checking dependencies...")
    
    # Check basic dependencies
    basic_deps = ['fastapi', 'uvicorn', 'selenium', 'speech_recognition', 'pydub']
    for dep in basic_deps:
        try:
            __import__(dep)
            print(f"✅ {dep} is installed")
        except ImportError as e:
            print(f"❌ {dep} import failed: {e}")
            return False
    
    # Special handling for undetected_chromedriver
    print("🔍 Checking undetected_chromedriver...")
    try:
        import undetected_chromedriver
        print("✅ undetected_chromedriver is installed")
        return True
    except ImportError as e:
        print(f"❌ undetected_chromedriver import failed: {e}")
        print("Attempting to reinstall undetected_chromedriver...")
        
        try:
            # Try to reinstall the package
            subprocess.check_call([sys.executable, "-m", "pip", "uninstall", "-y", "undetected-chromedriver"])
            subprocess.check_call([sys.executable, "-m", "pip", "install", "undetected-chromedriver==3.5.4"])
            
            # Test import again
            import undetected_chromedriver
            print("✅ undetected_chromedriver reinstalled and working")
            return True
        except Exception as reinstall_error:
            print(f"❌ Failed to reinstall undetected_chromedriver: {reinstall_error}")
            print("Please manually run:")
            print("pip uninstall undetected-chromedriver")
            print("pip install undetected-chromedriver==3.5.4")
            return False

def check_chrome():
    """Check if Chrome is available"""
    print("🔍 Checking Chrome installation...")
    
    try:
        # Try to find Chrome executable
        if sys.platform == "win32":
            chrome_paths = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
            ]
        elif sys.platform == "darwin":  # macOS
            chrome_paths = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
        else:  # Linux
            chrome_paths = ["google-chrome", "chromium-browser", "chromium"]
        
        chrome_found = False
        for path in chrome_paths:
            try:
                if os.path.exists(path) or subprocess.run([path, "--version"], 
                                                        capture_output=True, 
                                                        timeout=5).returncode == 0:
                    print(f"✅ Chrome found: {path}")
                    chrome_found = True
                    break
            except:
                continue
        
        if not chrome_found:
            print("⚠️  Chrome not found. Please install Google Chrome.")
            return False
        
        return True
    except Exception as e:
        print(f"❌ Error checking Chrome: {e}")
        return False

def start_server():
    """Start the API server"""
    print("🚀 Starting reCAPTCHA v2 Enterprise Solver API...")
    
    try:
        # Import and run the main module
        from main import main
        main()
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        return False
    
    return True

def main():
    """Main function"""
    print("🎯 reCAPTCHA v2 Enterprise Solver - Alternative Start")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Check Chrome
    if not check_chrome():
        print("⚠️  Chrome is required but not found. The solver may not work properly.")
        response = input("Continue anyway? (y/N): ")
        if response.lower() != 'y':
            sys.exit(1)
    
    print("\n✅ All checks passed!")
    print("Starting server...")
    print("API will be available at: http://localhost:8000")
    print("Press Ctrl+C to stop the server")
    print("=" * 50)
    
    # Start the server
    start_server()

if __name__ == "__main__":
    main() 