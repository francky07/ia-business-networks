#!/usr/bin/env python3
"""
Example: Spotify Login CAPTCHA Solving

This example demonstrates how to use the reCAPTCHA solver API
to solve CAPTCHA challenges during Spotify login.
"""

import requests
import json
import time

# API Configuration
API_BASE_URL = "http://localhost:8000"

def solve_spotify_captcha_direct():
    """Solve Spotify CAPTCHA using direct endpoint"""
    
    # Spotify-specific CAPTCHA data
    captcha_data = {
        "websiteURL": "https://accounts.spotify.com",
        "websiteKey": "6LfCVLAUAAAAAL9ttkwIz40hC63_7IsaR2MgimVj",
        "enterprisePayload": None  # Add your enterprise payload here
    }
    
    print("Solving Spotify CAPTCHA (direct method)...")
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/solve",
            json=captcha_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            if result["success"]:
                print(f"✅ CAPTCHA solved successfully!")
                print(f"Token: {result['token'][:50]}...")
                print(f"Attempts: {result['attempts']}")
                return result["token"]
            else:
                print(f"❌ CAPTCHA solving failed: {result['error']}")
                return None
        else:
            print(f"❌ API request failed: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def solve_spotify_captcha_capsolver_style():
    """Solve Spotify CAPTCHA using Capsolver API emulation"""
    
    # Step 1: Create task
    create_task_data = {
        "clientKey": "your_client_key",  # Any value accepted
        "task": {
            "type": "RecaptchaV2EnterpriseTaskProxyless",
            "websiteURL": "https://accounts.spotify.com",
            "websiteKey": "6LfCVLAUAAAAAL9ttkwIz40hC63_7IsaR2MgimVj",
            "enterprisePayload": None  # Add your enterprise payload here
        }
    }
    
    print("Creating CAPTCHA solving task...")
    
    try:
        # Create task
        response = requests.post(
            f"{API_BASE_URL}/createTask",
            json=create_task_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code != 200:
            print(f"❌ Failed to create task: {response.status_code}")
            return None
            
        result = response.json()
        if result["errorId"] != 0:
            print(f"❌ Task creation failed: {result['errorDescription']}")
            return None
            
        task_id = result["taskId"]
        print(f"✅ Task created: {task_id}")
        
        # Step 2: Poll for result
        print("Waiting for CAPTCHA solution...")
        
        max_wait_time = 300  # 5 minutes
        start_time = time.time()
        
        while time.time() - start_time < max_wait_time:
            time.sleep(5)  # Wait 5 seconds between checks
            
            get_result_data = {
                "clientKey": "your_client_key",
                "taskId": task_id
            }
            
            response = requests.post(
                f"{API_BASE_URL}/getTaskResult",
                json=get_result_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code != 200:
                print(f"❌ Failed to get task result: {response.status_code}")
                continue
                
            result = response.json()
            
            if result["errorId"] != 0:
                print(f"❌ Task failed: {result['errorDescription']}")
                return None
                
            if result["status"] == "ready":
                token = result["solution"]["token"]
                print(f"✅ CAPTCHA solved successfully!")
                print(f"Token: {token[:50]}...")
                return token
            elif result["status"] == "processing":
                print("⏳ Still processing...")
            else:
                print(f"❌ Unknown status: {result['status']}")
                return None
        
        print("❌ Timeout waiting for solution")
        return None
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

def use_token_for_spotify_login(token):
    """Example of using the CAPTCHA token for Spotify login"""
    
    # This is an example of how you might use the token
    # The actual implementation depends on your specific use case
    
    login_data = {
        "username": "your_spotify_username",
        "password": "your_spotify_password",
        "g-recaptcha-response": token,
        # Add other required fields
    }
    
    print("Using token for Spotify login...")
    print("Note: This is just an example - implement according to your needs")
    
    # Example request (you'll need to adapt this to your actual implementation)
    # response = requests.post(
    #     "https://accounts.spotify.com/api/login",
    #     data=login_data,
    #     headers={
    #         "User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36"
    #     }
    # )
    
    return True

def main():
    """Main function"""
    print("🎵 Spotify CAPTCHA Solver Example")
    print("=" * 50)
    
    # Method 1: Direct solving
    print("\n1. Direct Method:")
    token1 = solve_spotify_captcha_direct()
    
    if token1:
        use_token_for_spotify_login(token1)
    
    print("\n" + "=" * 50)
    
    # Method 2: Capsolver-style API
    print("\n2. Capsolver API Emulation:")
    token2 = solve_spotify_captcha_capsolver_style()
    
    if token2:
        use_token_for_spotify_login(token2)
    
    print("\n✅ Example completed!")

if __name__ == "__main__":
    main() 