#!/usr/bin/env python3
"""
reCAPTCHA v2 Enterprise Solver Client

A client library that emulates the Capsolver API for seamless integration
with existing code that uses Capsolver.
"""

import requests
import time
import json
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class CaptchaSolverClient:
    """
    Client for the reCAPTCHA v2 Enterprise Solver API
    Emulates the Capsolver API structure
    """
    
    def __init__(self, api_url: str = "http://localhost:8000", client_key: str = "free_solver"):
        """
        Initialize the client
        
        Args:
            api_url: URL of the CAPTCHA solver API
            client_key: Client key (any value accepted)
        """
        self.api_url = api_url.rstrip('/')
        self.client_key = client_key
        self.session = requests.Session()
        
    def create_task(self, task_type: str, website_url: str, website_key: str, 
                   enterprise_payload: str = None, **kwargs) -> Dict[str, Any]:
        """
        Create a CAPTCHA solving task (Capsolver API emulation)
        
        Args:
            task_type: Type of task (should be "RecaptchaV2EnterpriseTaskProxyless")
            website_url: URL of the website with CAPTCHA
            website_key: reCAPTCHA site key
            enterprise_payload: Enterprise payload (optional)
            **kwargs: Additional task parameters
            
        Returns:
            Dict containing task ID and status
        """
        task_data = {
            "type": task_type,
            "websiteURL": website_url,
            "websiteKey": website_key,
            "enterprisePayload": enterprise_payload,
            **kwargs
        }
        
        request_data = {
            "clientKey": self.client_key,
            "task": task_data
        }
        
        try:
            response = self.session.post(
                f"{self.api_url}/createTask",
                json=request_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                if result["errorId"] == 0:
                    logger.info(f"Task created successfully: {result['taskId']}")
                    return result
                else:
                    raise Exception(f"Task creation failed: {result['errorDescription']}")
            else:
                raise Exception(f"API request failed: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error creating task: {e}")
            raise
    
    def get_task_result(self, task_id: str) -> Dict[str, Any]:
        """
        Get the result of a CAPTCHA solving task
        
        Args:
            task_id: Task ID from create_task
            
        Returns:
            Dict containing task status and solution
        """
        request_data = {
            "clientKey": self.client_key,
            "taskId": task_id
        }
        
        try:
            response = self.session.post(
                f"{self.api_url}/getTaskResult",
                json=request_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                if result["errorId"] == 0:
                    return result
                else:
                    raise Exception(f"Task failed: {result['errorDescription']}")
            else:
                raise Exception(f"API request failed: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error getting task result: {e}")
            raise
    
    def solve_recaptcha_v2_enterprise(self, website_url: str, website_key: str, 
                                    enterprise_payload: str = None, 
                                    max_wait_time: int = 300) -> str:
        """
        Solve reCAPTCHA v2 Enterprise challenge (convenience method)
        
        Args:
            website_url: URL of the website with CAPTCHA
            website_key: reCAPTCHA site key
            enterprise_payload: Enterprise payload (optional)
            max_wait_time: Maximum time to wait for solution (seconds)
            
        Returns:
            CAPTCHA token
        """
        # Create task
        result = self.create_task(
            task_type="RecaptchaV2EnterpriseTaskProxyless",
            website_url=website_url,
            website_key=website_key,
            enterprise_payload=enterprise_payload
        )
        
        task_id = result["taskId"]
        logger.info(f"Waiting for solution of task {task_id}...")
        
        # Poll for result
        start_time = time.time()
        while time.time() - start_time < max_wait_time:
            time.sleep(5)  # Wait 5 seconds between checks
            
            try:
                result = self.get_task_result(task_id)
                
                if result["status"] == "ready":
                    token = result["solution"]["token"]
                    logger.info("CAPTCHA solved successfully!")
                    return token
                elif result["status"] == "processing":
                    logger.debug("Still processing...")
                else:
                    raise Exception(f"Unknown status: {result['status']}")
                    
            except Exception as e:
                logger.error(f"Error checking task result: {e}")
                raise
        
        raise Exception("Timeout waiting for CAPTCHA solution")
    
    def solve_direct(self, website_url: str, website_key: str, 
                    enterprise_payload: str = None) -> str:
        """
        Solve CAPTCHA directly (synchronous)
        
        Args:
            website_url: URL of the website with CAPTCHA
            website_key: reCAPTCHA site key
            enterprise_payload: Enterprise payload (optional)
            
        Returns:
            CAPTCHA token
        """
        request_data = {
            "websiteURL": website_url,
            "websiteKey": website_key,
            "enterprisePayload": enterprise_payload
        }
        
        try:
            response = self.session.post(
                f"{self.api_url}/solve",
                json=request_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                if result["success"]:
                    logger.info("CAPTCHA solved successfully!")
                    return result["token"]
                else:
                    raise Exception(f"CAPTCHA solving failed: {result['error']}")
            else:
                raise Exception(f"API request failed: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error in direct solve: {e}")
            raise
    
    def solve_spotify_login(self, enterprise_payload: str = None) -> str:
        """
        Solve Spotify login CAPTCHA specifically
        
        Args:
            enterprise_payload: Enterprise payload (optional)
            
        Returns:
            CAPTCHA token
        """
        return self.solve_direct(
            website_url="https://accounts.spotify.com",
            website_key="6LfCVLAUAAAAAL9ttkwIz40hC63_7IsaR2MgimVj",
            enterprise_payload=enterprise_payload
        )

# Convenience functions for backward compatibility
def solve_recaptcha_v2_enterprise(website_url: str, website_key: str, 
                                 enterprise_payload: str = None,
                                 api_url: str = "http://localhost:8000") -> str:
    """
    Convenience function to solve reCAPTCHA v2 Enterprise
    
    Args:
        website_url: URL of the website with CAPTCHA
        website_key: reCAPTCHA site key
        enterprise_payload: Enterprise payload (optional)
        api_url: URL of the CAPTCHA solver API
        
    Returns:
        CAPTCHA token
    """
    client = CaptchaSolverClient(api_url)
    return client.solve_direct(website_url, website_key, enterprise_payload)

def solve_spotify_captcha(enterprise_payload: str = None,
                         api_url: str = "http://localhost:8000") -> str:
    """
    Convenience function to solve Spotify CAPTCHA
    
    Args:
        enterprise_payload: Enterprise payload (optional)
        api_url: URL of the CAPTCHA solver API
        
    Returns:
        CAPTCHA token
    """
    client = CaptchaSolverClient(api_url)
    return client.solve_spotify_login(enterprise_payload)

# Example usage
if __name__ == "__main__":
    # Example 1: Using the client class
    client = CaptchaSolverClient()
    
    try:
        # Solve Spotify CAPTCHA
        token = client.solve_spotify_login()
        print(f"Spotify CAPTCHA token: {token[:50]}...")
        
        # Solve generic CAPTCHA
        token2 = client.solve_direct(
            website_url="https://example.com",
            website_key="your_site_key_here"
        )
        print(f"Generic CAPTCHA token: {token2[:50]}...")
        
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 2: Using convenience functions
    try:
        token = solve_spotify_captcha()
        print(f"Spotify CAPTCHA token (convenience): {token[:50]}...")
    except Exception as e:
        print(f"Error: {e}") 