import os
import time
import uuid
import base64
import requests
import speech_recognition as sr
from pydub import AudioSegment
from pydub.playback import play
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import logging
from typing import Optional, Dict, Any
import tempfile

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RecaptchaV2EnterpriseSolver:
    """
    reCAPTCHA v2 Enterprise solver using sound-based approach
    """
    
    def __init__(self, headless: bool = True, timeout: int = 30):
        self.headless = headless
        self.timeout = timeout
        self.driver = None
        self.recognizer = sr.Recognizer()
        
    def _setup_driver(self):
        """Initialize undetected Chrome driver"""
        try:
            options = uc.ChromeOptions()
            if self.headless:
                options.add_argument('--headless')
            
            # Add arguments to avoid detection
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option('useAutomationExtension', False)
            
            # Set user agent to mobile (for Spotify mobile app)
            options.add_argument('--user-agent=Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36')
            
            # Additional options for better compatibility
            options.add_argument('--disable-gpu')
            options.add_argument('--disable-web-security')
            options.add_argument('--allow-running-insecure-content')
            options.add_argument('--disable-features=VizDisplayCompositor')
            
            # For Apple Silicon Macs, ensure we use the right architecture
            import platform
            if platform.machine() == 'arm64':
                # Force download of ARM64 version
                options.add_argument('--disable-extensions')
                options.add_argument('--disable-plugins')
            
            self.driver = uc.Chrome(options=options, version_main=None)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            
            logger.info("Chrome driver initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Chrome driver: {e}")
            # Try alternative approach
            try:
                logger.info("Trying alternative Chrome driver setup...")
                options = uc.ChromeOptions()
                if self.headless:
                    options.add_argument('--headless')
                
                options.add_argument('--no-sandbox')
                options.add_argument('--disable-dev-shm-usage')
                options.add_argument('--disable-blink-features=AutomationControlled')
                options.add_experimental_option("excludeSwitches", ["enable-automation"])
                options.add_experimental_option('useAutomationExtension', False)
                
                # Use system Chrome path for Apple Silicon
                import platform
                if platform.machine() == 'arm64':
                    chrome_path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
                    if os.path.exists(chrome_path):
                        options.binary_location = chrome_path
                
                self.driver = uc.Chrome(options=options, version_main=None)
                self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                logger.info("Chrome driver initialized successfully with alternative setup")
                return True
                
            except Exception as e2:
                logger.error(f"Alternative Chrome driver setup also failed: {e2}")
                return False
    
    def _wait_for_element(self, by, value, timeout=None):
        """Wait for element to be present"""
        timeout = timeout or self.timeout
        try:
            element = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return element
        except TimeoutException:
            logger.error(f"Element not found: {by}={value}")
            return None
    
    def _find_recaptcha_iframe(self):
        """Find the reCAPTCHA iframe"""
        try:
            # Look for reCAPTCHA iframe
            iframe = self.driver.find_element(By.XPATH, "//iframe[contains(@src, 'recaptcha')]")
            return iframe
        except NoSuchElementException:
            logger.error("reCAPTCHA iframe not found")
            return None
    
    def _switch_to_recaptcha_frame(self):
        """Switch to reCAPTCHA iframe"""
        iframe = self._find_recaptcha_iframe()
        if iframe:
            self.driver.switch_to.frame(iframe)
            return True
        return False
    
    def _click_audio_challenge(self):
        """Click the audio challenge button"""
        try:
            # Wait for the reCAPTCHA checkbox to appear
            checkbox = self._wait_for_element(By.CLASS_NAME, "recaptcha-checkbox-border")
            if checkbox:
                checkbox.click()
                logger.info("Clicked reCAPTCHA checkbox")
            
            # Switch back to main content
            self.driver.switch_to.default_content()
            
            # Wait for challenge to appear and switch to challenge frame
            time.sleep(2)
            challenge_frame = self.driver.find_element(By.XPATH, "//iframe[contains(@src, 'recaptcha/api2/bframe')]")
            self.driver.switch_to.frame(challenge_frame)
            
            # Click audio challenge button
            audio_button = self._wait_for_element(By.ID, "recaptcha-audio-button")
            if audio_button:
                audio_button.click()
                logger.info("Clicked audio challenge button")
                return True
                
        except Exception as e:
            logger.error(f"Failed to click audio challenge: {e}")
            return False
    
    def _download_audio_file(self):
        """Download the audio file from reCAPTCHA"""
        try:
            # Wait for audio to load
            time.sleep(3)
            
            # Find the audio source
            audio_element = self.driver.find_element(By.TAG_NAME, "audio")
            audio_src = audio_element.get_attribute("src")
            
            if not audio_src:
                logger.error("Audio source not found")
                return None
            
            # Download the audio file
            response = requests.get(audio_src)
            if response.status_code == 200:
                # Save to temporary file
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
                temp_file.write(response.content)
                temp_file.close()
                logger.info(f"Audio file downloaded: {temp_file.name}")
                return temp_file.name
            else:
                logger.error(f"Failed to download audio: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to download audio file: {e}")
            return None
    
    def _convert_audio_to_text(self, audio_file_path: str) -> Optional[str]:
        """Convert audio file to text using speech recognition"""
        try:
            # Convert MP3 to WAV for speech recognition
            audio = AudioSegment.from_mp3(audio_file_path)
            wav_path = audio_file_path.replace('.mp3', '.wav')
            audio.export(wav_path, format="wav")
            
            # Use speech recognition
            with sr.AudioFile(wav_path) as source:
                audio_data = self.recognizer.record(source)
                text = self.recognizer.recognize_google(audio_data)
                logger.info(f"Recognized text: {text}")
                return text
                
        except sr.UnknownValueError:
            logger.error("Speech recognition could not understand audio")
            return None
        except sr.RequestError as e:
            logger.error(f"Speech recognition service error: {e}")
            return None
        except Exception as e:
            logger.error(f"Audio conversion error: {e}")
            return None
        finally:
            # Clean up temporary files
            try:
                os.unlink(audio_file_path)
                if os.path.exists(wav_path):
                    os.unlink(wav_path)
            except:
                pass
    
    def _submit_solution(self, text: str) -> bool:
        """Submit the recognized text as solution"""
        try:
            # Find the text input field
            text_input = self.driver.find_element(By.ID, "audio-response")
            text_input.clear()
            text_input.send_keys(text)
            
            # Click verify button
            verify_button = self.driver.find_element(By.ID, "recaptcha-verify-button")
            verify_button.click()
            
            logger.info("Solution submitted")
            return True
            
        except Exception as e:
            logger.error(f"Failed to submit solution: {e}")
            return False
    
    def _check_success(self) -> bool:
        """Check if CAPTCHA was solved successfully"""
        try:
            # Switch back to main content
            self.driver.switch_to.default_content()
            
            # Wait a moment for the result
            time.sleep(3)
            
            # Check if reCAPTCHA is still present
            try:
                self.driver.find_element(By.XPATH, "//iframe[contains(@src, 'recaptcha')]")
                return False
            except NoSuchElementException:
                return True
                
        except Exception as e:
            logger.error(f"Error checking success: {e}")
            return False
    
    def solve(self, website_url: str, website_key: str, enterprise_payload: str = None) -> Dict[str, Any]:
        """
        Solve reCAPTCHA v2 Enterprise challenge
        
        Args:
            website_url: URL of the website with CAPTCHA
            website_key: reCAPTCHA site key
            enterprise_payload: Enterprise payload (optional)
            
        Returns:
            Dict containing success status and token
        """
        if not self._setup_driver():
            return {"success": False, "error": "Failed to initialize driver"}
        
        try:
            # Navigate to the website
            self.driver.get(website_url)
            logger.info(f"Navigated to: {website_url}")
            
            # Wait for page to load
            time.sleep(3)
            
            # Try to solve CAPTCHA
            max_attempts = 3
            for attempt in range(max_attempts):
                logger.info(f"Attempt {attempt + 1}/{max_attempts}")
                
                # Switch to reCAPTCHA frame and click audio challenge
                if not self._switch_to_recaptcha_frame():
                    continue
                
                if not self._click_audio_challenge():
                    continue
                
                # Download and process audio
                audio_file = self._download_audio_file()
                if not audio_file:
                    continue
                
                # Convert audio to text
                text = self._convert_audio_to_text(audio_file)
                if not text:
                    continue
                
                # Submit solution
                if not self._submit_solution(text):
                    continue
                
                # Check if successful
                if self._check_success():
                    # Extract the token
                    token = self._extract_token()
                    logger.info("CAPTCHA solved successfully!")
                    return {
                        "success": True,
                        "token": token,
                        "attempts": attempt + 1
                    }
                
                # If not successful, try again
                time.sleep(2)
            
            return {"success": False, "error": "Max attempts reached"}
            
        except Exception as e:
            logger.error(f"Error during solving: {e}")
            return {"success": False, "error": str(e)}
        
        finally:
            if self.driver:
                self.driver.quit()
    
    def _extract_token(self) -> Optional[str]:
        """Extract the reCAPTCHA token from the page"""
        try:
            # Look for the token in various possible locations
            token_selectors = [
                'input[name="g-recaptcha-response"]',
                '#g-recaptcha-response',
                '[name="g-recaptcha-response"]'
            ]
            
            for selector in token_selectors:
                try:
                    element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    token = element.get_attribute("value")
                    if token:
                        return token
                except NoSuchElementException:
                    continue
            
            # If not found in elements, try to extract from JavaScript
            token = self.driver.execute_script("""
                return window.grecaptcha && window.grecaptcha.getResponse();
            """)
            
            return token
            
        except Exception as e:
            logger.error(f"Failed to extract token: {e}")
            return None 