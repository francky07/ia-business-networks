#!/usr/bin/env python3
"""
Simple Chrome driver test
"""

import undetected_chromedriver as uc
import time
import logging
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_chrome_driver():
    """Test Chrome driver initialization"""
    print("🔍 Testing Chrome driver initialization...")
    
    try:
        options = uc.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        # Additional options for better compatibility
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-web-security')
        options.add_argument('--allow-running-insecure-content')
        options.add_argument('--disable-features=VizDisplayCompositor')
        
        # For Apple Silicon Macs
        import platform
        if platform.machine() == 'arm64':
            options.add_argument('--disable-extensions')
            options.add_argument('--disable-plugins')
            chrome_path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
            if os.path.exists(chrome_path):
                options.binary_location = chrome_path
        
        print("✅ Chrome options configured")
        
        driver = uc.Chrome(options=options, version_main=None)
        print("✅ Chrome driver created successfully")
        
        # Test navigation
        driver.get("https://www.google.com")
        print("✅ Successfully navigated to Google")
        
        # Get page title
        title = driver.title
        print(f"✅ Page title: {title}")
        
        driver.quit()
        print("✅ Chrome driver test completed successfully")
        return True
        
    except Exception as e:
        print(f"❌ Chrome driver test failed: {e}")
        return False

if __name__ == "__main__":
    test_chrome_driver() 