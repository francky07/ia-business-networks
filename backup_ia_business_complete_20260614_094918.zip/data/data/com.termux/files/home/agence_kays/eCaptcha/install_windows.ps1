# reCAPTCHA v2 Enterprise Solver - Windows Installation Script
Write-Host "========================================" -ForegroundColor Green
Write-Host "reCAPTCHA v2 Enterprise Solver" -ForegroundColor Green
Write-Host "Windows Installation Script" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

Write-Host "`nStep 1: Updating pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip

Write-Host "`nStep 2: Installing setuptools and wheel..." -ForegroundColor Yellow
pip install "setuptools>=65.0.0" "wheel>=0.38.0"

Write-Host "`nStep 3: Installing PyAudio using helper script..." -ForegroundColor Yellow
python install_pyaudio_windows.py

Write-Host "`nStep 4: Installing other dependencies..." -ForegroundColor Yellow
pip install -r requirements_windows.txt

Write-Host "`nStep 5: Verifying installation..." -ForegroundColor Yellow
try {
    python -c "import fastapi, selenium, undetected_chromedriver, speech_recognition, pydub; print('All dependencies installed successfully!')"
    Write-Host "✅ Installation completed successfully!" -ForegroundColor Green
}
catch {
    Write-Host "❌ Installation verification failed. Please check the error messages above." -ForegroundColor Red
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "Installation completed!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "`nTo start the server, run:" -ForegroundColor Cyan
Write-Host "python start.py" -ForegroundColor White
Write-Host "`nPress any key to continue..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 