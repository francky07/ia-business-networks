#!/usr/bin/env python3
"""
reCAPTCHA v2 Enterprise Solver - Main Entry Point

A free, unlimited reCAPTCHA v2 Enterprise solver that uses sound-based approach
and emulates the Capsolver API structure for seamless integration.
"""

import os
import sys
import logging
from dotenv import load_dotenv
import uvicorn

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('captcha_solver.log')
    ]
)

logger = logging.getLogger(__name__)

def main():
    """Main entry point"""
    try:
        # Get configuration from environment
        host = os.getenv("API_HOST", "0.0.0.0")
        port = int(os.getenv("API_PORT", "8000"))
        reload = os.getenv("RELOAD", "true").lower() == "true"
        
        logger.info(f"Starting reCAPTCHA v2 Enterprise Solver API")
        logger.info(f"Host: {host}")
        logger.info(f"Port: {port}")
        logger.info(f"Reload: {reload}")
        
        # Start the API server
        uvicorn.run(
            "api_server:app",
            host=host,
            port=port,
            reload=reload,
            log_level="info"
        )
        
    except KeyboardInterrupt:
        logger.info("Shutting down gracefully...")
    except Exception as e:
        logger.error(f"Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 