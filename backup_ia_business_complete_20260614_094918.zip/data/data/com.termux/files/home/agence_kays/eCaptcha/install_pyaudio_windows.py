#!/usr/bin/env python3
"""
PyAudio Installation Helper for Windows
Handles multiple installation methods with fallbacks
"""

import subprocess
import sys
import os
import platform
from pathlib import Path

def run_command(command, description):
    """Run a command and return success status"""
    print(f"🔧 {description}...")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ {description} successful")
            return True
        else:
            print(f"❌ {description} failed: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ {description} error: {e}")
        return False

def check_pyaudio():
    """Check if PyAudio is already installed"""
    try:
        import pyaudio
        print("✅ PyAudio is already installed!")
        return True
    except ImportError:
        print("❌ PyAudio is not installed")
        return False

def get_python_version():
    """Get Python version info"""
    version = sys.version_info
    return f"{version.major}.{version.minor}.{version.micro}"

def get_python_arch():
    """Get Python architecture"""
    return "win_amd64" if platform.architecture()[0] == "64bit" else "win32"

def install_pyaudio_method1():
    """Method 1: Try direct pip install"""
    return run_command("pip install pyaudio", "Installing PyAudio via pip")

def install_pyaudio_method2():
    """Method 2: Try with --no-deps"""
    return run_command("pip install pyaudio --no-deps", "Installing PyAudio without dependencies")

def install_pyaudio_method3():
    """Method 3: Try with pre-built wheel from Christoph Gohlke"""
    python_version = get_python_version()
    python_arch = get_python_arch()
    
    # Map Python version to wheel version
    version_map = {
        "3.8": "cp38",
        "3.9": "cp39", 
        "3.10": "cp310",
        "3.11": "cp311",
        "3.12": "cp312"
    }
    
    py_version = version_map.get(f"{sys.version_info.major}.{sys.version_info.minor}")
    if not py_version:
        print(f"❌ Unsupported Python version: {python_version}")
        return False
    
    wheel_url = f"https://download.lfd.uci.edu/pythonlibs/archived/PyAudio-0.2.11-{py_version}-{py_version}-{python_arch}.whl"
    
    print(f"🔧 Downloading PyAudio wheel for Python {python_version} ({python_arch})...")
    return run_command(f"pip install {wheel_url}", "Installing PyAudio from wheel")

def install_pyaudio_method4():
    """Method 4: Try with conda"""
    return run_command("conda install -c conda-forge pyaudio -y", "Installing PyAudio via conda")

def install_pyaudio_method5():
    """Method 5: Try with pipwin (alternative approach)"""
    # First uninstall pipwin if it exists
    run_command("pip uninstall pipwin -y", "Uninstalling old pipwin")
    
    # Install a specific version of pipwin
    if run_command("pip install pipwin==0.5.2", "Installing pipwin"):
        return run_command("pipwin install pyaudio", "Installing PyAudio via pipwin")
    return False

def install_pyaudio_method6():
    """Method 6: Manual download and install"""
    print("🔧 Manual PyAudio installation...")
    
    # Create a temporary script to download and install
    script_content = '''
import urllib.request
import subprocess
import sys
import os

# Download PyAudio wheel
url = "https://files.pythonhosted.org/packages/ab/42/b4f04721c5c5bfc196ce156b3c768998ef8c0ae3654ed29ea5020c749a6b/PyAudio-0.2.11.tar.gz"
filename = "PyAudio-0.2.11.tar.gz"

print("Downloading PyAudio source...")
urllib.request.urlretrieve(url, filename)

# Try to install
try:
    subprocess.run([sys.executable, "-m", "pip", "install", filename], check=True)
    print("PyAudio installed successfully!")
except:
    print("Failed to install from source")
finally:
    if os.path.exists(filename):
        os.remove(filename)
'''
    
    with open("install_pyaudio_temp.py", "w") as f:
        f.write(script_content)
    
    success = run_command("python install_pyaudio_temp.py", "Installing PyAudio from source")
    
    # Clean up
    if os.path.exists("install_pyaudio_temp.py"):
        os.remove("install_pyaudio_temp.py")
    
    return success

def main():
    """Main installation function"""
    print("🎵 PyAudio Installation Helper for Windows")
    print("=" * 50)
    
    # Check if already installed
    if check_pyaudio():
        return True
    
    print(f"Python version: {get_python_version()}")
    print(f"Architecture: {get_python_arch()}")
    print()
    
    # Try different installation methods
    methods = [
        ("Direct pip install", install_pyaudio_method1),
        ("Pip install without deps", install_pyaudio_method2),
        ("Pre-built wheel", install_pyaudio_method3),
        ("Conda install", install_pyaudio_method4),
        ("Pipwin (alternative)", install_pyaudio_method5),
        ("Manual source install", install_pyaudio_method6)
    ]
    
    for method_name, method_func in methods:
        print(f"\n🔄 Trying: {method_name}")
        print("-" * 30)
        
        if method_func():
            # Verify installation
            if check_pyaudio():
                print(f"\n🎉 PyAudio installed successfully using: {method_name}")
                return True
            else:
                print(f"⚠️ Installation appeared successful but PyAudio not found")
        
        print()
    
    print("❌ All installation methods failed!")
    print("\n📋 Manual Installation Options:")
    print("1. Install Visual Studio Build Tools")
    print("2. Use a different Python version (3.8-3.11)")
    print("3. Use Anaconda/Miniconda")
    print("4. Download pre-built wheel manually")
    
    return False

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1) 