#!/usr/bin/env python3
"""
Test script to diagnose import issues
"""

import sys
import os

def test_imports():
    """Test various import scenarios"""
    print("🔍 Testing imports...")
    print(f"Python version: {sys.version}")
    print(f"Python path: {sys.executable}")
    print(f"Current working directory: {os.getcwd()}")
    
    # Test basic imports
    try:
        import fastapi
        print("✅ fastapi imported successfully")
    except ImportError as e:
        print(f"❌ fastapi import failed: {e}")
    
    try:
        import selenium
        print("✅ selenium imported successfully")
    except ImportError as e:
        print(f"❌ selenium import failed: {e}")
    
    # Test undetected_chromedriver imports
    print("\n🔍 Testing undetected_chromedriver...")
    
    try:
        import undetected_chromedriver
        print("✅ undetected_chromedriver imported successfully")
    except ImportError as e:
        print(f"❌ undetected_chromedriver import failed: {e}")
    
    try:
        import undetected_chromedriver as uc
        print("✅ undetected_chromedriver imported as uc successfully")
    except ImportError as e:
        print(f"❌ undetected_chromedriver as uc import failed: {e}")
    
    # Check if the module exists in site-packages
    import site
    for path in site.getsitepackages():
        undetected_path = os.path.join(path, 'undetected_chromedriver')
        if os.path.exists(undetected_path):
            print(f"✅ Found undetected_chromedriver at: {undetected_path}")
            break
    else:
        print("❌ undetected_chromedriver not found in site-packages")

if __name__ == "__main__":
    test_imports() 