# Installation Guide

This guide will help you install and set up the reCAPTCHA v2 Enterprise Solver on your system.

## Prerequisites

- Python 3.8 or higher
- Google Chrome browser
- Internet connection

## Quick Start (Recommended)

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd recaptcha_v2_solver
   ```

2. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start the server:**
   ```bash
   python start.py
   ```

The API will be available at `http://localhost:8000`

## Detailed Installation by OS

### Windows

1. **Install Python:**
   - Download Python 3.8+ from [python.org](https://www.python.org/downloads/)
   - Make sure to check "Add Python to PATH" during installation

2. **Install Google Chrome:**
   - Download from [google.com/chrome](https://www.google.com/chrome/)
   - Install normally

3. **Install dependencies:**
   ```cmd
   pip install -r requirements.txt
   ```

4. **Start the server:**
   ```cmd
   python start.py
   ```

### macOS

1. **Install Python:**
   ```bash
   # Using Homebrew (recommended)
   brew install python@3.9
   
   # Or download from python.org
   ```

2. **Install Chrome:**
   ```bash
   brew install --cask google-chrome
   ```

3. **Install audio dependencies:**
   ```bash
   brew install portaudio
   ```

4. **Install Python dependencies:**
   ```bash
   pip3 install -r requirements.txt
   ```

5. **Start the server:**
   ```bash
   python3 start.py
   ```

### Linux (Ubuntu/Debian)

1. **Install system dependencies:**
   ```bash
   sudo apt-get update
   sudo apt-get install -y python3 python3-pip python3-venv
   sudo apt-get install -y google-chrome-stable
   sudo apt-get install -y portaudio19-dev python3-pyaudio
   sudo apt-get install -y ffmpeg
   ```

2. **Create virtual environment (recommended):**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Start the server:**
   ```bash
   python start.py
   ```

### Linux (CentOS/RHEL/Fedora)

1. **Install system dependencies:**
   ```bash
   # CentOS/RHEL
   sudo yum install -y python3 python3-pip
   sudo yum install -y google-chrome-stable
   sudo yum install -y portaudio-devel
   sudo yum install -y ffmpeg
   
   # Fedora
   sudo dnf install -y python3 python3-pip
   sudo dnf install -y google-chrome-stable
   sudo dnf install -y portaudio-devel
   sudo dnf install -y ffmpeg
   ```

2. **Install Python dependencies:**
   ```bash
   pip3 install -r requirements.txt
   ```

3. **Start the server:**
   ```bash
   python3 start.py
   ```

## Docker Installation

If you prefer using Docker:

1. **Install Docker:**
   - Follow instructions at [docker.com](https://docs.docker.com/get-docker/)

2. **Build and run:**
   ```bash
   docker-compose up -d
   ```

3. **Check status:**
   ```bash
   docker-compose ps
   ```

## Troubleshooting

### Common Issues

#### 1. PyAudio Installation Fails

**Windows:**
```bash
pip install pipwin
pipwin install pyaudio
```

**macOS:**
```bash
brew install portaudio
pip install pyaudio
```

**Linux:**
```bash
sudo apt-get install portaudio19-dev python3-pyaudio
pip install pyaudio
```

#### 2. Chrome Not Found

Make sure Google Chrome is installed and accessible:

**Windows:**
- Check if Chrome is in `C:\Program Files\Google\Chrome\Application\chrome.exe`

**macOS:**
- Check if Chrome is in `/Applications/Google Chrome.app/`

**Linux:**
```bash
which google-chrome
# or
which chromium-browser
```

#### 3. Permission Errors

**Linux/macOS:**
```bash
chmod +x start.py
chmod +x main.py
```

#### 4. Port Already in Use

Change the port in the configuration:

```bash
# Set environment variable
export API_PORT=8001

# Or edit .env file
echo "API_PORT=8001" > .env
```

#### 5. Audio Processing Issues

Make sure audio dependencies are installed:

**Ubuntu/Debian:**
```bash
sudo apt-get install -y ffmpeg portaudio19-dev
```

**macOS:**
```bash
brew install ffmpeg portaudio
```

**Windows:**
- Download ffmpeg from [ffmpeg.org](https://ffmpeg.org/download.html)
- Add to PATH

### Testing Installation

After installation, test the setup:

```bash
python test_solver.py
```

This will run a comprehensive test suite to verify everything is working.

### Getting Help

If you encounter issues:

1. Check the logs in `captcha_solver.log`
2. Run the test suite: `python test_solver.py`
3. Check the API health: `curl http://localhost:8000/health`
4. Review the troubleshooting section above

## Next Steps

After successful installation:

1. **Read the README.md** for usage instructions
2. **Check examples/** for usage examples
3. **Review the API documentation** at `http://localhost:8000/docs`
4. **Test with your specific use case**

## Security Notes

- This tool is for educational and research purposes
- Use responsibly and comply with website terms of service
- Consider rate limiting and ethical usage
- Keep your system and dependencies updated 