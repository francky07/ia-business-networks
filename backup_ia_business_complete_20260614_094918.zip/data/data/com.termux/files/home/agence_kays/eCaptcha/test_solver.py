#!/usr/bin/env python3
"""
Test script for reCAPTCHA v2 Enterprise Solver

This script tests the CAPTCHA solver functionality and API endpoints.
"""

import requests
import time
import json
import sys
from captcha_client import CaptchaSolverClient

def test_api_health():
    """Test API health endpoint"""
    print("🔍 Testing API health...")
    
    try:
        response = requests.get("http://localhost:8000/health")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ API is healthy")
            print(f"   Status: {data['status']}")
            print(f"   Active tasks: {data['active_tasks']}")
            return True
        else:
            print(f"❌ API health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ API health check error: {e}")
        return False

def test_direct_solve():
    """Test direct solve endpoint"""
    print("\n🔍 Testing direct solve endpoint...")
    
    # Test data (using a test site)
    test_data = {
        "websiteURL": "https://www.google.com/recaptcha/api2/demo",
        "websiteKey": "6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-",
        "enterprisePayload": None
    }
    
    try:
        response = requests.post(
            "http://localhost:8000/solve",
            json=test_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Direct solve response received")
            print(f"   Success: {result['success']}")
            if result['success']:
                print(f"   Token: {result['token'][:50]}...")
                print(f"   Attempts: {result['attempts']}")
            else:
                print(f"   Error: {result['error']}")
            return result['success']
        else:
            print(f"❌ Direct solve failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Direct solve error: {e}")
        return False

def test_capsolver_api():
    """Test Capsolver API emulation"""
    print("\n🔍 Testing Capsolver API emulation...")
    
    client = CaptchaSolverClient()
    
    try:
        # Test task creation
        print("   Creating task...")
        result = client.create_task(
            task_type="RecaptchaV2EnterpriseTaskProxyless",
            website_url="https://www.google.com/recaptcha/api2/demo",
            website_key="6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-"
        )
        
        task_id = result["taskId"]
        print(f"   ✅ Task created: {task_id}")
        
        # Test task result polling
        print("   Polling for result...")
        max_wait = 60  # 1 minute timeout for testing
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            time.sleep(5)
            
            try:
                result = client.get_task_result(task_id)
                
                if result["status"] == "ready":
                    print(f"   ✅ Task completed successfully")
                    print(f"   Token: {result['solution']['token'][:50]}...")
                    return True
                elif result["status"] == "processing":
                    print("   ⏳ Still processing...")
                elif result["status"] == "failed":
                    print(f"   ❌ Task failed: {result.get('errorDescription', 'Unknown error')}")
                    return False
                    
            except Exception as e:
                print(f"   ❌ Error polling result: {e}")
                return False
        
        print("   ❌ Timeout waiting for result")
        return False
        
    except Exception as e:
        print(f"   ❌ Capsolver API test error: {e}")
        return False

def test_spotify_endpoint():
    """Test Spotify-specific endpoint"""
    print("\n🔍 Testing Spotify endpoint...")
    
    try:
        response = requests.post(
            "http://localhost:8000/spotify/login",
            json={"enterprisePayload": None},
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Spotify endpoint response received")
            print(f"   Success: {result['success']}")
            if result['success']:
                print(f"   Token: {result['token'][:50]}...")
            else:
                print(f"   Error: {result['error']}")
            return result['success']
        else:
            print(f"❌ Spotify endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Spotify endpoint error: {e}")
        return False

def test_client_library():
    """Test the client library"""
    print("\n🔍 Testing client library...")
    
    try:
        client = CaptchaSolverClient()
        
        # Test direct solve
        print("   Testing direct solve...")
        token = client.solve_direct(
            website_url="https://www.google.com/recaptcha/api2/demo",
            website_key="6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-"
        )
        
        if token:
            print(f"   ✅ Direct solve successful")
            print(f"   Token: {token[:50]}...")
            return True
        else:
            print(f"   ❌ Direct solve failed")
            return False
            
    except Exception as e:
        print(f"   ❌ Client library test error: {e}")
        return False

def main():
    """Main test function"""
    print("🧪 reCAPTCHA v2 Enterprise Solver - Test Suite")
    print("=" * 60)
    
    # Check if API is running
    if not test_api_health():
        print("\n❌ API is not running. Please start the server first:")
        print("   python main.py")
        sys.exit(1)
    
    # Run tests
    tests = [
        ("Direct Solve", test_direct_solve),
        ("Capsolver API", test_capsolver_api),
        ("Spotify Endpoint", test_spotify_endpoint),
        ("Client Library", test_client_library),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            results.append((test_name, False))
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 Test Results Summary:")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<20} {status}")
        if result:
            passed += 1
    
    print("=" * 60)
    print(f"Total: {total}, Passed: {passed}, Failed: {total - passed}")
    
    if passed == total:
        print("🎉 All tests passed!")
        return 0
    else:
        print("⚠️  Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 