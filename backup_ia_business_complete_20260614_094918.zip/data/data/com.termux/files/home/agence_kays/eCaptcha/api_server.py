import os
import uuid
import time
import asyncio
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import logging
from captcha_solver_simple import SimpleRecaptchaSolver
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="reCAPTCHA v2 Enterprise Solver API",
    description="Free reCAPTCHA v2 Enterprise solver with Capsolver API emulation",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for tasks (in production, use Redis or database)
tasks: Dict[str, Dict[str, Any]] = {}

# Pydantic models for request/response validation
class TaskRequest(BaseModel):
    clientKey: str = Field(..., description="Client key (any value accepted)")
    task: Dict[str, Any] = Field(..., description="Task configuration")

class TaskResultRequest(BaseModel):
    clientKey: str = Field(..., description="Client key")
    taskId: str = Field(..., description="Task ID to check")

class DirectSolveRequest(BaseModel):
    websiteURL: str = Field(..., description="Website URL with CAPTCHA")
    websiteKey: str = Field(..., description="reCAPTCHA site key")
    enterprisePayload: Optional[str] = Field(None, description="Enterprise payload")

class TaskResponse(BaseModel):
    errorId: int = Field(0, description="Error ID (0 = success)")
    errorCode: Optional[str] = Field(None, description="Error code")
    errorDescription: Optional[str] = Field(None, description="Error description")
    taskId: Optional[str] = Field(None, description="Task ID")

class TaskResultResponse(BaseModel):
    errorId: int = Field(0, description="Error ID (0 = success)")
    errorCode: Optional[str] = Field(None, description="Error code")
    errorDescription: Optional[str] = Field(None, description="Error description")
    status: Optional[str] = Field(None, description="Task status")
    solution: Optional[Dict[str, Any]] = Field(None, description="Solution data")

class DirectSolveResponse(BaseModel):
    success: bool = Field(..., description="Success status")
    token: Optional[str] = Field(None, description="reCAPTCHA token")
    error: Optional[str] = Field(None, description="Error message")
    attempts: Optional[int] = Field(None, description="Number of attempts")

class SpotifyLoginRequest(BaseModel):
    enterprisePayload: Optional[str] = Field(None, description="Enterprise payload")

def solve_captcha_task(task_id: str, task_data: Dict[str, Any]):
    """Background task to solve CAPTCHA"""
    try:
        # Extract task parameters
        website_url = task_data.get("websiteURL")
        website_key = task_data.get("websiteKey")
        enterprise_payload = task_data.get("enterprisePayload")
        
        # Initialize solver
        solver = SimpleRecaptchaSolver(
            timeout=int(os.getenv("AUDIO_TIMEOUT", "30"))
        )
        
        # Solve CAPTCHA
        result = solver.solve(website_url, website_key, enterprise_payload)
        
        # Update task status
        if result["success"]:
            tasks[task_id]["status"] = "ready"
            tasks[task_id]["solution"] = {
                "token": result["token"],
                "gRecaptchaResponse": result["token"]
            }
            tasks[task_id]["completed_at"] = time.time()
        else:
            tasks[task_id]["status"] = "failed"
            tasks[task_id]["error"] = result.get("error", "Unknown error")
            
    except Exception as e:
        logger.error(f"Error solving task {task_id}: {e}")
        tasks[task_id]["status"] = "failed"
        tasks[task_id]["error"] = str(e)

@app.post("/createTask", response_model=TaskResponse)
async def create_task(request: TaskRequest, background_tasks: BackgroundTasks):
    """
    Create a new CAPTCHA solving task (Capsolver API emulation)
    """
    try:
        # Validate task type
        task_type = request.task.get("type")
        if task_type != "RecaptchaV2EnterpriseTaskProxyless":
            return TaskResponse(
                errorId=1,
                errorCode="ERROR_TASK_TYPE_NOT_SUPPORTED",
                errorDescription=f"Task type '{task_type}' is not supported"
            )
        
        # Generate task ID
        task_id = str(uuid.uuid4())
        
        # Store task data
        tasks[task_id] = {
            "status": "processing",
            "task_data": request.task,
            "created_at": time.time(),
            "solution": None,
            "error": None
        }
        
        # Start solving in background
        background_tasks.add_task(solve_captcha_task, task_id, request.task)
        
        logger.info(f"Created task {task_id} for {request.task.get('websiteURL')}")
        
        return TaskResponse(
            errorId=0,
            taskId=task_id
        )
        
    except Exception as e:
        logger.error(f"Error creating task: {e}")
        return TaskResponse(
            errorId=1,
            errorCode="ERROR_CREATE_TASK",
            errorDescription=str(e)
        )

@app.post("/getTaskResult", response_model=TaskResultResponse)
async def get_task_result(request: TaskResultRequest):
    """
    Get the result of a CAPTCHA solving task (Capsolver API emulation)
    """
    try:
        task_id = request.taskId
        
        if task_id not in tasks:
            return TaskResultResponse(
                errorId=1,
                errorCode="ERROR_TASK_NOT_FOUND",
                errorDescription=f"Task {task_id} not found"
            )
        
        task = tasks[task_id]
        
        if task["status"] == "processing":
            return TaskResultResponse(
                errorId=0,
                status="processing"
            )
        elif task["status"] == "ready":
            return TaskResultResponse(
                errorId=0,
                status="ready",
                solution=task["solution"]
            )
        elif task["status"] == "failed":
            return TaskResultResponse(
                errorId=1,
                errorCode="ERROR_SOLVING_FAILED",
                errorDescription=task.get("error", "Solving failed")
            )
        else:
            return TaskResultResponse(
                errorId=1,
                errorCode="ERROR_UNKNOWN_STATUS",
                errorDescription=f"Unknown status: {task['status']}"
            )
            
    except Exception as e:
        logger.error(f"Error getting task result: {e}")
        return TaskResultResponse(
            errorId=1,
            errorCode="ERROR_GET_TASK_RESULT",
            errorDescription=str(e)
        )

@app.post("/solve", response_model=DirectSolveResponse)
async def solve_direct(request: DirectSolveRequest):
    """
    Direct CAPTCHA solving endpoint (simplified)
    """
    try:
        # Initialize solver
        solver = SimpleRecaptchaSolver(
            timeout=int(os.getenv("AUDIO_TIMEOUT", "30"))
        )
        
        # Solve CAPTCHA
        result = solver.solve(
            request.websiteURL,
            request.websiteKey,
            request.enterprisePayload
        )
        
        return DirectSolveResponse(
            success=result["success"],
            token=result.get("token"),
            error=result.get("error"),
            attempts=result.get("attempts")
        )
        
    except Exception as e:
        logger.error(f"Error in direct solve: {e}")
        return DirectSolveResponse(
            success=False,
            error=str(e)
        )

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "active_tasks": len([t for t in tasks.values() if t["status"] == "processing"])
    }

@app.get("/tasks")
async def list_tasks():
    """List all tasks (for debugging)"""
    return {
        "tasks": tasks,
        "total": len(tasks)
    }

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: str):
    """Delete a task (for cleanup)"""
    if task_id in tasks:
        del tasks[task_id]
        return {"message": f"Task {task_id} deleted"}
    else:
        raise HTTPException(status_code=404, detail="Task not found")

# Spotify-specific endpoints
@app.post("/spotify/login")
async def spotify_login_solve(request: SpotifyLoginRequest):
    """
    Spotify-specific login CAPTCHA solver
    """
    try:
        # Initialize solver
        solver = SimpleRecaptchaSolver(
            timeout=int(os.getenv("AUDIO_TIMEOUT", "30"))
        )
        
        # Solve CAPTCHA with Spotify-specific settings
        result = solver.solve(
            website_url="https://accounts.spotify.com",
            website_key="6LfCVLAUAAAAAL9ttkwIz40hC63_7IsaR2MgimVj",
            enterprise_payload=request.enterprisePayload
        )
        
        return DirectSolveResponse(
            success=result["success"],
            token=result.get("token"),
            error=result.get("error"),
            attempts=result.get("attempts")
        )
        
    except Exception as e:
        logger.error(f"Error in Spotify solve: {e}")
        return DirectSolveResponse(
            success=False,
            error=str(e)
        )

if __name__ == "__main__":
    import uvicorn
    
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    
    uvicorn.run(
        "api_server:app",
        host=host,
        port=port,
        reload=True
    ) 