@echo off
echo ========================================
echo reCAPTCHA v2 Enterprise Solver
echo Windows Installation Script
echo ========================================

echo.
echo Step 1: Updating pip...
python -m pip install --upgrade pip

echo.
echo Step 2: Installing setuptools and wheel...
pip install setuptools>=65.0.0 wheel>=0.38.0

echo.
echo Step 3: Installing PyAudio using helper script...
python install_pyaudio_windows.py

echo.
echo Step 4: Installing other dependencies...
pip install -r requirements_windows.txt

echo.
echo Step 5: Verifying installation...
python -c "import fastapi, selenium, undetected_chromedriver, speech_recognition, pydub; print('All dependencies installed successfully!')"

echo.
echo ========================================
echo Installation completed!
echo ========================================
echo.
echo To start the server, run:
echo python start.py
echo.
pause 